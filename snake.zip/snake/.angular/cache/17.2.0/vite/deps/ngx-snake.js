import {
  AsyncPipe,
  CommonModule,
  NgForOf
} from "./chunk-ZUMKBNNC.js";
import {
  BehaviorSubject,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Injectable,
  Input,
  NgModule,
  Output,
  Renderer2,
  ReplaySubject,
  Subject,
  ViewEncapsulation$1,
  filter,
  interval,
  setClassMetadata,
  switchMap,
  take,
  tap,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵtemplate
} from "./chunk-2CAAISBL.js";

// node_modules/ngx-snake/fesm2020/ngx-snake.mjs
function BoardComponent_div_0_ngx_snake_tile_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ngx-snake-tile", 3);
  }
  if (rf & 2) {
    const tileState_r3 = ctx.$implicit;
    ɵɵproperty("state", tileState_r3);
  }
}
function BoardComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, BoardComponent_div_0_ngx_snake_tile_1_Template, 1, 1, "ngx-snake-tile", 2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const row_r1 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("ngForOf", row_r1);
  }
}
var GameState;
(function(GameState2) {
  GameState2[GameState2["Paused"] = 0] = "Paused";
  GameState2[GameState2["Started"] = 1] = "Started";
  GameState2[GameState2["Over"] = 2] = "Over";
})(GameState || (GameState = {}));
var TileState;
(function(TileState2) {
  TileState2["Free"] = "free";
  TileState2["Head"] = "head";
  TileState2["Body"] = "body";
  TileState2["Tail"] = "tail";
  TileState2["Wall"] = "wall";
  TileState2["Food"] = "food";
})(TileState || (TileState = {}));
var MoveDirections;
(function(MoveDirections2) {
  MoveDirections2[MoveDirections2["UP"] = 0] = "UP";
  MoveDirections2[MoveDirections2["RIGHT"] = 1] = "RIGHT";
  MoveDirections2[MoveDirections2["DOWN"] = 2] = "DOWN";
  MoveDirections2[MoveDirections2["LEFT"] = 3] = "LEFT";
})(MoveDirections || (MoveDirections = {}));
var INITIAL_SPEED = 700;
var GameManagerService = class {
  constructor() {
    this._grid = [];
    this._grid$ = new ReplaySubject(1);
    this.grid$ = this._grid$.asObservable();
    this._gameOver$ = new Subject();
    this.gameOver$ = this._gameOver$;
    this._foodEaten$ = new Subject();
    this.foodEaten$ = this._foodEaten$;
    this._gridSize = {
      h: 10,
      w: 10
    };
    this._snake = [];
    this._nextMoveDir = MoveDirections.RIGHT;
    this._moveDir = MoveDirections.RIGHT;
    this._food = null;
    this._interval$ = new BehaviorSubject(INITIAL_SPEED);
    this._paused = true;
    this._playable = true;
    this.signal$ = this._interval$.asObservable().pipe(switchMap((period) => interval(period)), filter(() => !this._paused), tap(() => this._gameCycle()));
  }
  initialize(height, width) {
    this._gridSize.w = width;
    this._gridSize.h = height;
    this._buildEmptyGrid();
    this._initSnake();
    this._drawSnake();
    this._gridChanged();
    this._signalSub = this.signal$.subscribe();
  }
  ngOnDestroy() {
    if (this._signalSub) {
      this._signalSub.unsubscribe();
    }
  }
  start() {
    if (this._playable) {
      this._paused = false;
    }
  }
  changeSpeed(period) {
    this._interval$.next(period);
  }
  pause() {
    this._paused = true;
  }
  reset() {
    this.pause();
    this._playable = true;
    this._moveDir = MoveDirections.RIGHT;
    this._nextMoveDir = this._moveDir;
    this._interval$.next(INITIAL_SPEED);
    this._buildEmptyGrid();
    this._initSnake();
    this._drawSnake();
    this._gridChanged();
  }
  up() {
    this._moveDir !== MoveDirections.DOWN ? this._nextMoveDir = MoveDirections.UP : this._moveDir;
  }
  right() {
    this._moveDir !== MoveDirections.LEFT ? this._nextMoveDir = MoveDirections.RIGHT : this._moveDir;
  }
  down() {
    this._moveDir !== MoveDirections.UP ? this._nextMoveDir = MoveDirections.DOWN : this._moveDir;
  }
  left() {
    this._moveDir !== MoveDirections.RIGHT ? this._nextMoveDir = MoveDirections.LEFT : this._moveDir;
  }
  _endGame() {
    this._playable = false;
    this.pause();
    this._gameOver$.next();
  }
  _buildEmptyGrid() {
    const newGrid = [];
    for (let y = 0; y <= this._gridSize.h; y++) {
      const row = [];
      for (let x = 0; x <= this._gridSize.w; x++) {
        row.push(TileState.Free);
      }
      newGrid.push(row);
    }
    this._grid = newGrid;
  }
  _gridChanged() {
    this._grid$.next(this._grid);
  }
  _initSnake() {
    this._snake = [];
    const xCenter = Math.floor(this._gridSize.w / 2);
    const yCenter = Math.floor(this._gridSize.h / 2);
    this._snake.push({
      x: xCenter,
      y: yCenter
    });
    this._snake.push({
      x: xCenter - 1,
      y: yCenter
    });
    this._snake.push({
      x: xCenter - 2,
      y: yCenter
    });
  }
  _spawnFood() {
    if (!this._food) {
      const eligibleFields = [];
      for (let y = 1; y <= this._gridSize.h - 1; y++) {
        for (let x = 1; x <= this._gridSize.w - 1; x++) {
          if (this._grid[y][x] === TileState.Free) {
            eligibleFields.push({
              x,
              y
            });
          }
        }
      }
      const shuffled = eligibleFields.sort((a, b) => 0.5 - Math.random());
      this._food = shuffled[0];
    }
    this._grid[this._food.y][this._food.x] = TileState.Food;
  }
  _drawSnake() {
    const head = this._snake[0];
    const tail = this._snake[this._snake.length - 1];
    this._grid[head.y][head.x] = TileState.Head;
    for (let i = 1; i < this._snake.length - 1; i++) {
      const part = this._snake[i];
      this._grid[part.y][part.x] = TileState.Body;
    }
    this._grid[tail.y][tail.x] = TileState.Tail;
  }
  _gameCycle() {
    const head = this._snake[0];
    let newHead;
    this._moveDir = this._nextMoveDir;
    if (this._moveDir === MoveDirections.UP) {
      newHead = {
        x: head.x,
        y: head.y - 1
      };
    } else if (this._moveDir === MoveDirections.RIGHT) {
      newHead = {
        x: head.x + 1,
        y: head.y
      };
    } else if (this._moveDir === MoveDirections.DOWN) {
      newHead = {
        x: head.x,
        y: head.y + 1
      };
    } else {
      newHead = {
        x: head.x - 1,
        y: head.y
      };
    }
    if (this._willCrash(newHead)) {
      return this._endGame();
    }
    this._snake.unshift(newHead);
    if (this._willGrow(newHead)) {
      this._increaseSpeed();
      this._foodEaten$.next();
      this._food = null;
    } else {
      this._snake.pop();
    }
    this._buildEmptyGrid();
    this._drawSnake();
    this._spawnFood();
    this._gridChanged();
  }
  /**
   * Checks if field is not currently occupied (is free to take)
   * @param newHead
   * @private
   */
  _willCrash(newHead) {
    if (newHead.x < 0 || newHead.y < 0 || newHead.x > this._gridSize.w || newHead.y > this._gridSize.h) {
      return true;
    }
    const CRASHABLE_FIELDS = [TileState.Body, TileState.Wall];
    if (CRASHABLE_FIELDS.includes(this._grid[newHead.y][newHead.x])) {
      return true;
    }
    if (this._grid[newHead.y][newHead.x] === TileState.Tail && this._willGrow(newHead)) {
      return true;
    }
    return false;
  }
  _willGrow(newHead) {
    if (this._food && this._food.y === newHead.y && this._food.x === newHead.x) {
      return true;
    }
    return false;
  }
  _increaseSpeed() {
    this._interval$.pipe(take(1)).subscribe((current) => {
      if (current >= 600) {
        this._interval$.next(current - 100);
      } else if (current >= 500) {
        this._interval$.next(current - 30);
      } else if (current >= 400) {
        this._interval$.next(current - 20);
      } else {
        this._interval$.next(current - 10);
      }
    });
  }
};
GameManagerService.ɵfac = function GameManagerService_Factory(t) {
  return new (t || GameManagerService)();
};
GameManagerService.ɵprov = ɵɵdefineInjectable({
  token: GameManagerService,
  factory: GameManagerService.ɵfac
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(GameManagerService, [{
    type: Injectable
  }], null, null);
})();
var TileComponent = class {
  constructor(el, _renderer) {
    this.el = el;
    this._renderer = _renderer;
  }
  ngOnInit() {
    if (this.state) {
      this._renderer.addClass(this.el.nativeElement, this.state);
    }
  }
};
TileComponent.ɵfac = function TileComponent_Factory(t) {
  return new (t || TileComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2));
};
TileComponent.ɵcmp = ɵɵdefineComponent({
  type: TileComponent,
  selectors: [["ngx-snake-tile"]],
  inputs: {
    state: "state"
  },
  decls: 1,
  vars: 0,
  template: function TileComponent_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelement(0, "div");
    }
  },
  styles: ["ngx-snake-tile{display:block;background:#ccf1ed;border:1px solid #4e4645;width:25px;height:25px;float:left;margin:1px;box-sizing:border-box}ngx-snake-tile div{height:100%;width:100%;display:block;background:#ccf1ed}ngx-snake-tile.free div{background:#ccf1ed}ngx-snake-tile.head div{background:#4e6c31}ngx-snake-tile.body div{background:#4e6c31}ngx-snake-tile.tail div{background:#4e6c31}ngx-snake-tile.wall div{background:#C2C3C7}ngx-snake-tile.food{padding:3px}ngx-snake-tile.food div{background:#00E436}\n"],
  encapsulation: 2,
  changeDetection: 0
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TileComponent, [{
    type: Component,
    args: [{
      selector: "ngx-snake-tile",
      template: `<div></div>`,
      encapsulation: ViewEncapsulation$1.None,
      changeDetection: ChangeDetectionStrategy.OnPush,
      styles: ["ngx-snake-tile{display:block;background:#ccf1ed;border:1px solid #4e4645;width:25px;height:25px;float:left;margin:1px;box-sizing:border-box}ngx-snake-tile div{height:100%;width:100%;display:block;background:#ccf1ed}ngx-snake-tile.free div{background:#ccf1ed}ngx-snake-tile.head div{background:#4e6c31}ngx-snake-tile.body div{background:#4e6c31}ngx-snake-tile.tail div{background:#4e6c31}ngx-snake-tile.wall div{background:#C2C3C7}ngx-snake-tile.food{padding:3px}ngx-snake-tile.food div{background:#00E436}\n"]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: Renderer2
    }];
  }, {
    state: [{
      type: Input
    }]
  });
})();
var BoardComponent = class {
  constructor() {
  }
  ngOnInit() {
  }
};
BoardComponent.ɵfac = function BoardComponent_Factory(t) {
  return new (t || BoardComponent)();
};
BoardComponent.ɵcmp = ɵɵdefineComponent({
  type: BoardComponent,
  selectors: [["ngx-snake-board"]],
  inputs: {
    data: "data"
  },
  decls: 1,
  vars: 1,
  consts: [["class", "ngx-snake-board-row", 4, "ngFor", "ngForOf"], [1, "ngx-snake-board-row"], [3, "state", 4, "ngFor", "ngForOf"], [3, "state"]],
  template: function BoardComponent_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, BoardComponent_div_0_Template, 2, 1, "div", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngForOf", ctx.data);
    }
  },
  dependencies: [TileComponent, NgForOf],
  styles: ["[_nghost-%COMP%]   .ngx-snake-board-row[_ngcontent-%COMP%]{display:block;clear:both}"]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BoardComponent, [{
    type: Component,
    args: [{
      selector: "ngx-snake-board",
      template: '<div class="ngx-snake-board-row" *ngFor="let row of data">\n    <ngx-snake-tile *ngFor="let tileState of row"\n                    [state]="tileState"></ngx-snake-tile>\n</div>\n',
      styles: [":host .ngx-snake-board-row{display:block;clear:both}\n"]
    }]
  }], function() {
    return [];
  }, {
    data: [{
      type: Input
    }]
  });
})();
var NgxSnakeComponent = class {
  constructor(_manager) {
    this._manager = _manager;
    this.boardHeight = 10;
    this.boardWidth = 10;
    this.foodEaten = this._manager.foodEaten$;
    this.gameOver = this._manager.gameOver$;
    this.grid$ = this._manager.grid$;
  }
  ngOnInit() {
    this._manager.initialize(this.boardHeight, this.boardWidth);
  }
  actionUp() {
    this._manager.up();
  }
  actionRight() {
    this._manager.right();
  }
  actionDown() {
    this._manager.down();
  }
  actionLeft() {
    this._manager.left();
  }
  actionStart() {
    this._manager.start();
  }
  actionStop() {
    this._manager.pause();
  }
  actionReset() {
    this._manager.reset();
  }
};
NgxSnakeComponent.ɵfac = function NgxSnakeComponent_Factory(t) {
  return new (t || NgxSnakeComponent)(ɵɵdirectiveInject(GameManagerService));
};
NgxSnakeComponent.ɵcmp = ɵɵdefineComponent({
  type: NgxSnakeComponent,
  selectors: [["ngx-snake"]],
  inputs: {
    boardHeight: "boardHeight",
    boardWidth: "boardWidth"
  },
  outputs: {
    foodEaten: "foodEaten",
    gameOver: "gameOver"
  },
  features: [ɵɵProvidersFeature([GameManagerService])],
  decls: 2,
  vars: 3,
  consts: [[3, "data"]],
  template: function NgxSnakeComponent_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelement(0, "ngx-snake-board", 0);
      ɵɵpipe(1, "async");
    }
    if (rf & 2) {
      ɵɵproperty("data", ɵɵpipeBind1(1, 1, ctx.grid$));
    }
  },
  dependencies: [BoardComponent, AsyncPipe],
  encapsulation: 2
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxSnakeComponent, [{
    type: Component,
    args: [{
      selector: "ngx-snake",
      template: `
        <ngx-snake-board
            [data]="grid$ | async"></ngx-snake-board>
    `,
      styles: [],
      providers: [GameManagerService]
    }]
  }], function() {
    return [{
      type: GameManagerService
    }];
  }, {
    boardHeight: [{
      type: Input
    }],
    boardWidth: [{
      type: Input
    }],
    foodEaten: [{
      type: Output
    }],
    gameOver: [{
      type: Output
    }]
  });
})();
var NgxSnakeModule = class _NgxSnakeModule {
  static forRoot() {
    return {
      ngModule: _NgxSnakeModule
    };
  }
};
NgxSnakeModule.ɵfac = function NgxSnakeModule_Factory(t) {
  return new (t || NgxSnakeModule)();
};
NgxSnakeModule.ɵmod = ɵɵdefineNgModule({
  type: NgxSnakeModule,
  declarations: [NgxSnakeComponent, BoardComponent, TileComponent],
  imports: [CommonModule],
  exports: [NgxSnakeComponent]
});
NgxSnakeModule.ɵinj = ɵɵdefineInjector({
  imports: [[CommonModule]]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxSnakeModule, [{
    type: NgModule,
    args: [{
      declarations: [NgxSnakeComponent, BoardComponent, TileComponent],
      imports: [CommonModule],
      exports: [NgxSnakeComponent]
    }]
  }], null, null);
})();
export {
  NgxSnakeComponent,
  NgxSnakeModule
};
//# sourceMappingURL=ngx-snake.js.map
